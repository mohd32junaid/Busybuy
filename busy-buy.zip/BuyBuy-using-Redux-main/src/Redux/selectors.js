
export const userSelector = (state) => state.userReducer.userUID;

export const productsSelector = (state) => state.productsReducer.products;

export const myCartSelector = (state) => state.myCartReducer.cartItems;